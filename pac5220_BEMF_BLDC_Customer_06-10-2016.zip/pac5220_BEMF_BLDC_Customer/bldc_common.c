/****************************************************************************
 * @file     bldc_common.c
 * @brief    Support functions for all BLDC Algorithms
 * @date     22 September 2015
 *
 * @note
 * Copyright (C) 2015, Active-Semi International
 *
 * THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES,
 * AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S
 * APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL;
 * (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT
 * ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
 * DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
 * ONLY BY CERTAIN AUTHORIZED PERSONS.
 ******************************************************************************/
#define INCLUDE_EXTERNS
#include "bldc_common.h"

/**
 * @brief  This is the interrupt handler for the SysTick which will be used to generate 1 ms periodic pulses to
 * 			run the main loop state machine.
 *
 * @return none
 *
 */
void SysTick_Handler(void)
{
	millisecond = 1;
}

/**
 * @brief  This is the interrupt handler for GPIOB, which is where the IRQ1 pin
 *         resides. If IRQ1 pin goes low, the LED will turn on.
 *
 *
 * @return none
 */
void GpioB_IRQHandler(void)
{
	if (PAC5XXX_GPIOB->INTF.b & NIRQ1_PIN_MASK)				//nPROT Output ISR - Over Current Protection
		{
		motor_pwm_disable();
		app_status |= status_over_current;
		PAC5XXX_GPIOB->INTF.b = NIRQ1_PIN_MASK;
		PAC5XXX_TIMERD->CCTRL0.CCINTEN = 0;			//NVIC_DisableIRQ(TimerD_IRQn);
		}
}

/**
 * @brief	This function configures dead time.
 *
 * @return none
 *
 */

void Set_Dead_Time(void)
{
	// Configure Hardware Dead time Generator
	pac5xxx_dtg_config(DTGA0, dt_leading_ticks, dt_trailing_ticks, 0, 0, 0, 0);				// Configure DTGA0
	pac5xxx_dtg_config(DTGA1, dt_leading_ticks, dt_trailing_ticks, 0, 0, 0, 0);				// Configure DTGA1
	pac5xxx_dtg_config(DTGA2, dt_leading_ticks, dt_trailing_ticks, 0, 0, 0, 0);				// Configure DTGA2
}

/**
 * @brief	This function clears Over Current Events and re-enables the power manager.
 *
 * @return none
 *
 */
void oc_reset(void)
{
	uint16_t register_val;

	// Disable global interrupts until OC reset is complete
	__disable_irq();

	// Clear int/fault flags
	pac5xxx_tile_register_write(ADDR_PROTINTM, 0x00);
	while (pac5xxx_tile_register_read(ADDR_PROTSTAT));
	pac5xxx_tile_register_write(ADDR_PROTINTM, 0x70);

	// Disable driver
	do {
		pac5xxx_tile_register_write(ADDR_ENDRV, 0);
		register_val = pac5xxx_tile_register_read(ADDR_ENDRV);
	} while ((register_val&0x1) != 0x0);


	// Enable global interrupts
	__enable_irq();

	pac5xxx_tile_register_write(ADDR_ENDRV, 1);

	// Update status
	app_status &= ~(status_motor_enabled + status_over_current);

	// Turn back on ADC and start for control processing. Motor still disabled until UART command.
	pac5xxx_adc_enable(1);

	pac5xxx_adc_start();
}

APP_RAMFUNC  void pac5xxx_tile_register_write_in(uint8_t address, uint8_t data)
{
	PAC5XXX_SOCBRIDGE->SOCBD.s = (((address << 1) | 1) << 8) | data;
	// Wait for transmission to be complete
	while (!PAC5XXX_SOCBRIDGE->SOCBSTAT.CYC_DONE);
	PAC5XXX_SOCBRIDGE->SOCBSTAT.CYC_DONE = 0x1;
}

/**
 * @brief	This function transforms the motor speed in Hz to the respective number of clock cycles required
 * 			The equation on this function is # ticks = PWM_FREQ / (6 * SpeedInHz)
 * 			The PWM_FREQ (units is KHz) is programmable and is computed in the UART module
 *
 * @return 	The number of clock cycles corresponding to the desired frequency
 *
 */

APP_RAMFUNC fix16_t HertzToTicks(fix16_t Hertz, uint32_t Freq)
{
	fix16_t tmp;
	tmp = fix16_mul_new_16_16(6 << 16, Hertz);						// Hz * 6 commutation states
	tmp = fix16_div(Freq, tmp);
	return tmp << 10; 												// Converted to fix16 after multiplying by 1024
}

fix16_t HertzToTicksSine(fix16_t Hertz, uint32_t Freq)
{
	fix16_t tmp;
	tmp = fix16_mul_new_16_16(360 << 16, Hertz);						// Hz * 6 commutation states
	tmp = fix16_div(Freq, tmp);
	return tmp << 10; 												// Converted to fix16 after multiplying by 1024

}

/**
 * @brief	This function gets the ADC conversions for the VIN scaler and the potentiometer
 *
 * @return 	NONE
 *
 */
void check_adc(void)
{
	vin_volts = fix16_mul_new_16_16((VIN_VOLTS_VAL << 16), VOLT_DIV_FIX16);
	pot_volts = POT_VOLTS_VAL; // << 16;
}

/**
 * @brief	This function checks the VIN scaled voltage and determines whether there is
 * 			enough battery voltage to maintain motor operational. When battery voltage is below
 * 			threshold, the motor is disabled.
 *
 * @return 	NONE
 *
 */

void check_vbat(void)
{
	if (vin_volts < VIN_VOLTS_LEGAL)
		{
		vin_check_debounce--;
		if (vin_check_debounce <= 0)
			{
			if (app_status & status_motor_enabled)
				{
				motor_pwm_disable();
				}
			app_status |= status_under_voltage;
			}
		}
	else
		{
		vin_check_debounce++;
		if (vin_check_debounce > VIN_CHECK_DEB_MAX)
			{
			vin_check_debounce = VIN_CHECK_DEB_MAX;
			app_status &= ~status_under_voltage;
			}
		}
}

/**
 * @brief	This function configures the H Bridge as a speaker driver and enables the motor
 * 			to apply a beep sound at the frequency of the musical notes denoted from 0 to 127
 *
 * @return 	NONE
 *
 */

void beep_on(int note)
{
	app_status &= ~status_motor_stalled;

	PAC5XXX_TIMERA->CTR4 = beep_pwm_dc;
	PAC5XXX_TIMERA->CTR5 = beep_pwm_dc;
	PAC5XXX_TIMERA->CTR6 = beep_pwm_dc;

	sl_current_state = 0;
#if PAC5250
	PAC5XXX_GPIOA->OUTEN.b = MOTOR_PWM_PIN_PORT_A;
	PAC5XXX_GPIOA->PSEL.s = psel_mask[sl_current_state];	        // Set peripheral select state

	PAC5XXX_GPIOD->OUTEN.b = MOTOR_PWM_PIN_PORT_D;
	PAC5XXX_GPIOD->PSEL.s = psel_mask_port_d[sl_current_state];
#else
	PAC5XXX_GPIOA->OUTEN.b = MOTOR_PWM_PIN_PORT_A;
	PAC5XXX_GPIOA->PSEL.s = psel_mask[sl_current_state];	        // Set peripheral select state
#endif
	sl_current_state++;

	app_status |= status_motor_enabled;
	open_loop = 1;
	sine_mode = 0;

	pac5xxx_timer_base_config(TimerD, beep_notes[note], 0, TxCTL_MODE_UP, 0);
	pac5xxx_timer_base_int_enable(TimerD, 1);									// Enable Timer D Base Interrupt
	NVIC_EnableIRQ(TimerD_IRQn);
}

/**
 * @brief	This function disables the H Bridge and stops the sound function
 *
 * @return 	NONE
 *
 */

void beep_off(void)
{
	PAC5XXX_GPIOA->OUT.b = 0;
	PAC5XXX_GPIOA->PSEL.s = 0;
	app_status &= ~status_motor_enabled;
	pac5xxx_timer_base_int_enable(TimerD, 0);									// Enable Timer D Base Interrupt
	NVIC_DisableIRQ(TimerD_IRQn);
	SMS_State = SMS_Idle;

}
