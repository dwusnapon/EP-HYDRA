/****************************************************************************
 * @file     hs_state_machine.c
 * @brief    State Machine For The Hall Sensor Based BLDC Application
 * @date     22 September 2015
 *
 * @note
 * Copyright (C) 2015, Active-Semi International
 *
 * THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES,
 * AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S
 * APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL;
 * (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT
 * ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
 * DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
 * ONLY BY CERTAIN AUTHORIZED PERSONS.
 ******************************************************************************/
#define INCLUDE_EXTERNS
#include "bldc_common.h"

#ifdef HALL_SENSOR_APP
/**
 * @brief  The state machine is in charge of coordination motor operation. Interval is 1 ms.
 *
 * @return none
 *
 */
void state_machine(void)
{
	switch (SMS_State)
	{

#if POT_CONTROL
	case SMS_Idle:
		if (!(app_status & status_under_voltage)&&(pot_volts > TURN_ON_THRESHOLD_MAX))
			{
			speed_ref_command_hz = pot_volts >> 1;
			SMS_State = SMS_Align;
			}
		break;
#else
	case SMS_Idle:
		// DO NOTHING
		break;

#endif
	case SMS_Align:
		sine_mode = 0;

		app_status &= ~status_motor_stalled;
		app_status |= status_motor_enabled;

#if PAC5223
		PAC5XXX_TIMERB->CCTRL0.CCINTEN = 1;
		PAC5XXX_TIMERB->CCTRL1.CCINTEN = 1;
		PAC5XXX_TIMERD->CCTRL0.CCINTEN = 1;
#else
		PAC5XXX_TIMERB->CCTRL0.CCINTEN = 1;
		PAC5XXX_TIMERB->CCTRL1.CCINTEN = 1;
		PAC5XXX_TIMERA->CCTRL7.CCINTEN = 1;
#endif



#if IREG
		iq_ref = start_iq_ref << 16;
		iq_pid.PI_sat = iq_pid.min_value;
		iq_pid.I_prev = iq_pid.min_value;

		speed_pid.PI_sat = iq_ref;
		speed_pid.I_prev = iq_ref;
#else
		speed_pid.PI_sat = iq_pid.min_value;
		speed_pid.I_prev = iq_pid.min_value;
#endif

		PAC5XXX_GPIOA->OUTEN.b = MOTOR_PWM_PIN_PORT_A;
#if PAC5250
		PAC5XXX_GPIOD->OUTEN.b = MOTOR_PWM_PIN_PORT_D;
#endif

		speed_ref_hz = ol_start_hz;
		commutate();

		uint32_t temp_speed = HertzToTicks((speed_ref_hz << 16), (TIMER_D_FREQ_F16 >> timer_d_div)) >> 16;

	  	// Initialize Average Speed Array
		// This is done after first commutation to ensure array is filled with good values.
		// The motor-speed value on the first commutate() execution is not maningful as it has no point of reference
		uint32_t i;
		for (i=0;i<=5;i++)
	      	{
	   		avg_speed_array[i] = temp_speed;
	      	}


		app_status |= status_closed_loop;

#if POT_CONTROL
		SMS_State = SMS_SpeedUpdate;
#else
		SMS_State = SMS_Idle;
#endif
		break;

	case SMS_SpeedUpdate:
		if (pot_volts > TURN_ON_THRESHOLD_MIN)
			{
			speed_ref_command_hz = pot_volts >> 1;
			}
		else
			{
			motor_pwm_disable();
			}
		break;
	}
}
#endif
