/****************************************************************************
 * @file     hs_peripheral_init.h
 * @brief    Peripheral Initialization for the Hall Sensor Based BLDC Application
 * @date     22 September 2015
 *
 * @note
 * Copyright (C) 2015, Active-Semi International
 *
 * THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES,
 * AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S
 * APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL;
 * (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT
 * ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
 * DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
 * ONLY BY CERTAIN AUTHORIZED PERSONS.
 ******************************************************************************/
#define INCLUDE_EXTERNS
#include "bldc_common.h"

#ifdef HALL_SENSOR_APP

/**
 * @brief  This function configures the PAC peripherals for this application
 *
 * @return none
 *
 */
void peripheral_init(void)
{

#if PLL_FREQ_100
	// PLL Enabled @ 100MHz, HCLK runs at 50 MHz, ACLK runs at 100 MHz
	pac5xxx_sys_ccs_config(CCSCTL_CLKIN_CLKREF, CCSCTL_ACLKDIV_DIV1, CCSCTL_HCLKDIV_DIV2);
	pac5xxx_sys_pll_config(100);
	pac5xxx_sys_ccs_pll_select();
	pac5xxx_memctl_wait_state(FLASH_WSTATE_75MHZ_LT_HCLK_LTE_100MHZ);
#else
	// PLL Enabled @ 50MHz, HCLK runs at 50 MHz, ACLK runs at 50 MHz
	pac5xxx_sys_ccs_config(CCSCTL_CLKIN_CLKREF, CCSCTL_ACLKDIV_DIV1, CCSCTL_HCLKDIV_DIV1);
	pac5xxx_sys_pll_config(50);
	pac5xxx_sys_ccs_pll_select();
	pac5xxx_memctl_wait_state(FLASH_WSTATE_25MHZ_LT_HCLK_LTE_50MHZ);
#endif

	// Configure Timer A parameters. Timer A runs at PLL Frequency (selected above).
	pac5xxx_timer_clock_config(TimerA, TxCTL_CS_ACLK, TxCTL_PS_DIV1);
	app_pwm_period = PWM_SWITCH_FREQ;												// Number of KHz
	pwm_period_ticks = TIMER_A_FREQ_CNV / (app_pwm_period);							// 50,000 / # KHz
	pac5xxx_timer_base_config(TimerA, pwm_period_ticks, 0, TxCTL_MODE_UP, 0);		// Configure Timer

	// Configure Hardware Dead Time Generator
	dt_leading_ticks = DT_LED_TICKS;
	dt_trailing_ticks = DT_TED_TICKS;
	Set_Dead_Time();

	pac5xxx_timer_cctrl_config(TimerA, 4, pwm_period_ticks >> 1, 0);				// Configure CCR for VL
	pac5xxx_timer_cctrl_config(TimerA, 5, pwm_period_ticks >> 1, 0);				// Configure CCR for WH
	pac5xxx_timer_cctrl_config(TimerA, 6, pwm_period_ticks >> 1, 0);				// Configure CCR for WL

	// Configure nIRQ1 interrupt input signals and enable interrupts
	pac5xxx_gpio_int_mask_b(NIRQ1_PIN_MASK);										// Set interrupt mask at startup (interrupt startup workaround)
	pac5xxx_gpio_int_polarity_b(0);													// Set interrupt polarity (high-to-low)
	pac5xxx_gpio_int_enable_b(NIRQ1_PIN_MASK);										// Enable interrupts in IO controller
	NVIC_SetPriority(GpioB_IRQn, 2);
	NVIC_EnableIRQ(GpioB_IRQn);														// Enable interrupts in NVIC
	pac5xxx_gpio_int_flag_clear_b(NIRQ1_PIN_MASK);									// Clear any active interrupt flags
	pac5xxx_gpio_int_mask_b(0);														// Clear interrupt mask and interrupts are enabled

#if SPI_SUPPORT
	pac5xxx_gpio_out_enable_e(0x30);												// Set PE5, PE4, PE3, and PE0 to output
#else
	pac5xxx_gpio_out_enable_e(0x39);												// Set PE5, PE4, PE3, and PE0 to output
#endif

#if PAC5223
	pac5xxx_gpio_out_pull_up_d(0x8C);
#else
	pac5xxx_gpio_out_pull_up_d(0x4C);
#endif

#if PAC5223
	pac5xxx_timer_io_select_pwmb0_pd2();													//Hall Sensor Input U 	- PD2	- PWMB0
	pac5xxx_timer_io_select_pwmb1_pd3();													//Hall Sensor Input V 	- PD3	- PWMB1
	pac5xxx_timer_io_select_pwmd0_pd7();													//Hall Sensor Input W 	- PD7	- PWMD0

	pac5xxx_timer_cctrl_capture_config(TimerB,1,0,1,TxCCTL_CED_BOTH);						//Hall Sensor Input U - Rise/Fall
	pac5xxx_timer_cctrl_capture_config(TimerB,1,1,1,TxCCTL_CED_BOTH);						//Hall Sensor Input V - Rise/Fall
	pac5xxx_timer_cctrl_capture_config(TimerD,1,0,1,TxCCTL_CED_BOTH);						//Hall Sensor Input W - Rise/Fall

#else
	pac5xxx_timer_io_select_pwmb0_pd2();													//Hall Sensor Input U 	- PD2	- PWMB0
	pac5xxx_timer_io_select_pwmb1_pd3();													//Hall Sensor Input V 	- PD3	- PWMB1
	pac5xxx_timer_io_select_pwma7_pd6();													//Hall Sensor Input W 	- PD6	- PWMA7

	pac5xxx_timer_cctrl_capture_config(TimerB,1,0,1,TxCCTL_CED_BOTH);						//Hall Sensor Input U - Rise/Fall
	pac5xxx_timer_cctrl_capture_config(TimerB,1,1,1,TxCCTL_CED_BOTH);						//Hall Sensor Input V - Rise/Fall
	pac5xxx_timer_cctrl_capture_config(TimerA,1,7,1,TxCCTL_CED_BOTH);						//Hall Sensor Input W - Rise/Fall
#endif

#if PAC5223
	NVIC_SetPriority(TimerD_IRQn, 1);														//Hall Sensor W
	NVIC_EnableIRQ(TimerD_IRQn);
#else
	NVIC_SetPriority(TimerAExt_IRQn, 1);													//Hall Sensor W
	NVIC_EnableIRQ(TimerAExt_IRQn);
#endif

	NVIC_SetPriority(TimerB_IRQn, 1);														//Hall Sensor U & V
	NVIC_EnableIRQ(TimerB_IRQn);

	timer_d_div = 4;
	pac5xxx_timer_clock_config(TimerD, TxCTL_CS_HCLK, timer_d_div);
	pac5xxx_timer_base_config(TimerD, 0xFFFF, 0, TxCTL_MODE_UP, 0);

	//Configure SysTick Timer
    SysTick->LOAD = 50000;
    SysTick->VAL = 0;
    SysTick->CTRL |= (SysTick_CTRL_ENABLE_Msk +  SysTick_CTRL_CLKSOURCE_Msk + SysTick_CTRL_TICKINT_Msk);
	NVIC_SetPriority(SysTick_IRQn, 3);
}
#endif
