/****************************************************************************
 * @file     isr_TimerA.c
 * @brief    Timer A Interrupt Service Routine
 * @date     22 September 2015
 *
 * @note
 * Copyright (C) 2015, Active-Semi International
 *
 * THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES,
 * AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S
 * APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL;
 * (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT
 * ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
 * DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
 * ONLY BY CERTAIN AUTHORIZED PERSONS.
 ******************************************************************************/
#define INCLUDE_EXTERNS
#include "bldc_common.h"

/**
 * @brief  This is the interrupt handler for Timer A.
 *
 * @return none
 *
 */
void TimerA_IRQHandler(void)
{
	if (PAC5XXX_TIMERA->CTL.INT && PAC5XXX_TIMERA->CTL.INTEN)
		{
		PAC5XXX_TIMERA->CTL.INT = 1;
		}
	if (PAC5XXX_TIMERA->CCTRL0.CCINT && PAC5XXX_TIMERA->CCTRL0.CCINTEN)
		{
		PAC5XXX_TIMERA->CCTRL0.CCINT = 1;
		}
	if (PAC5XXX_TIMERA->CCTRL1.CCINT && PAC5XXX_TIMERA->CCTRL1.CCINTEN)
		{
		PAC5XXX_TIMERA->CCTRL1.CCINT = 1;
		}
	if (PAC5XXX_TIMERA->CCTRL2.CCINT && PAC5XXX_TIMERA->CCTRL2.CCINTEN)
		{
		PAC5XXX_TIMERA->CCTRL2.CCINT = 1;
		}
	if (PAC5XXX_TIMERA->CCTRL3.CCINT && PAC5XXX_TIMERA->CCTRL3.CCINTEN)
		{
		PAC5XXX_TIMERA->CCTRL3.CCINT = 1;
		}
	if (PAC5XXX_TIMERA->CCTRL4.CCINT && PAC5XXX_TIMERA->CCTRL4.CCINTEN)
		{
		PAC5XXX_TIMERA->CCTRL4.CCINT = 1;
		}
	if (PAC5XXX_TIMERA->CCTRL5.CCINT && PAC5XXX_TIMERA->CCTRL5.CCINTEN)
		{
		PAC5XXX_TIMERA->CCTRL5.CCINT = 1;
		}
}

#if defined SENSORLESS_APP  || defined RC_PWM_THROTTLE_APP
void TimerAExt_IRQHandler(void)
{
	if (PAC5XXX_TIMERA->CCTRL6.CCINT && PAC5XXX_TIMERA->CCTRL6.CCINTEN)
		{
		PAC5XXX_TIMERA->CCTRL6.CCINT = 1;
		}
	if (PAC5XXX_TIMERA->CCTRL7.CCINT && PAC5XXX_TIMERA->CCTRL6.CCINTEN)
		{
		PAC5XXX_TIMERA->CCTRL7.CCINT = 1;
		}
}
#endif

#ifdef HALL_SENSOR_APP
/**
 * @brief Process Timer A Extended Interrupts
 * PWMA6 Not Used
 * PWMA7 PHASE W Hall Effect Sensor Input Capture (both rise and fall edges)
 */
APP_RAMFUNC void TimerAExt_IRQHandler(void)
{
#if PAC5223
	if (PAC5XXX_TIMERA->CCTRL7.CCINT && PAC5XXX_TIMERA->CCTRL7.CCINTEN)
		{
		PAC5XXX_TIMERA->CCTRL7.CCINT = 1; //pac5xxx_timer_a_cctrl_7_int_clear();
		}
#else
	if (PAC5XXX_TIMERA->CCTRL7.CCINT && PAC5XXX_TIMERA->CCTRL7.CCINTEN)
		{
		commutate();
		PAC5XXX_TIMERA->CCTRL7.CCINT = 1; //pac5xxx_timer_a_cctrl_7_int_clear();
		}
#endif
}
#endif
