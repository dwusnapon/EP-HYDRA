/****************************************************************************
 * @file     uart.c
 * @brief    Peripheral and initialization routines for the application.
 * @date     13 February 2015
 *
 * @note
 * Copyright (C) 2015, Active-Semi International
 *
 * THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES,
 * AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S
 * APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL;
 * (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT
 * ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
 * DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
 * ONLY BY CERTAIN AUTHORIZED PERSONS.
 ******************************************************************************/
#define INCLUDE_EXTERNS
#include "bldc_common.h"

#define SPI_MESSAGE_SIZE	2

uint32_t spi_buffer[SPI_MESSAGE_SIZE];
uint8_t spi_byte_count = 0;
uint8_t spi_opcode;
uint8_t spi_read_mode;

uint32_t b32_spi_data;											//SPI Data pulled from the SPI data register at the time of the SPI ISR
uint32_t spi_data;												//SPI Data extracted from the multi word packet. To be used by the application.

void spi_write_to_slave_process(void);
void spi_read_from_slave_process(void);

enum SPI_Parameter_Code
{
	// status commands
    parm_status,								//1
    parm_debug_1,
    parm_debug_2,
    parm_debug_3,
    parm_debug_4,
    parm_pwm_period,
    parm_over_current_limit,
    parm_dt_leading_ticks,
    parm_dt_trailing_ticks,
    parm_oc_reset,								//10
    parm_timer_d_div,
    parm_sample_delay,
    parm_vpot,
    parm_vin,
    parm_blanking_cycles,
    parm_good_samples,
    parm_motor_speed,
    parm_current_command,
    parm_current_Kp,
    parm_current_Ki,							//20
    parm_current_min,
    parm_current_max,
    parm_speed_command,
    parm_speed_Kp,
    parm_speed_Ki,
    parm_speed_min,
    parm_speed_max,
    parm_ol_accel_period,
    parm_ol_accel_increase,
    parm_on_off,								//30
    parm_stall_detect_speed_hz,
    parm_stall_detect_time_ms,
    parm_commutation_advanced_rise_delay,
    parm_commutation_advanced_fall_delay,
    parm_start_iq_ref,
    parm_align_time_ms,
    parm_ol_start_hz,
    parm_ol_switchover_hz,
    parm_cl_accel_period,
    parm_cl_accel_increase,						//40
    parm_debug_array,
    parm_pi_debug_index,
    parm_pi_debug_error,
	parm_pi_debug_p,
    parm_pi_debug_i,
    parm_pi_debug_pi,
    parm_pi_debug_pisat,
    parm_speed_ref_command_hz					//48
};


void SPIB_IRQHandler(void)
{

	PAC5XXX_GPIOE->OUT.b ^= 0x10;

	if (PAC5XXX_SPI->SPISTAT.CYC_DONE)
		{
		b32_spi_data = PAC5XXX_SPI->SPID.w;
		if (spi_byte_count == 0)								//For the first byte received, the start byte must be 0x89
			{
			if ((b32_spi_data >> 24) != 0x89)					// MSB 8 bits must equal 0x89 on the first SPI word
			{
				PAC5XXX_SPI->SPISTAT.CYC_DONE = 1;
				return;
			}

			if (((b32_spi_data & 0xFF0000) >> 16) & 0x80)		// Second MSB 8 bits, bit 7 indicates read (1) or write (0)
				{
				spi_read_mode = 1;
				spi_read_from_slave_process();
				}
			}

		spi_buffer[spi_byte_count++] = b32_spi_data;			//Store data in buffer and increment index

		if (spi_byte_count == SPI_MESSAGE_SIZE)					//Received all bytes of message
			{
			if (spi_read_mode)
				{
				spi_read_mode = 0;
				}
			else
				{
				spi_write_to_slave_process();								//Process incoming message in uart_rx_buffer and put response in uart_tx_buffer
				PAC5XXX_GPIOE->OUT.b ^= 0x20;
				}
			spi_byte_count = 0;
			}
		PAC5XXX_SPI->SPISTAT.CYC_DONE = 1;
		}
}

void spi_write_to_slave_process(void)
{

	spi_data = (spi_buffer[0] & 0xFFFF) << 16;
	spi_data |= (spi_buffer[1] & 0xFFFF);
	spi_opcode = (spi_buffer[0] & 0x7F0000) >> 16;

	switch (spi_opcode)			// Switch on command code
		{
		case parm_pwm_period:
			if (spi_data != app_pwm_period)
				{
				app_pwm_period = spi_data >> 16;							//Number of KHz
				//PWM ticks = 100 MHz / PWM FREQ KHz. Since 100,000 is too large, app_pwm_period is shifted 17 instead of 16 = multiplying by 2.
				pwm_period_ticks = TIMER_A_FREQ_CNV / (app_pwm_period);			//100,000 / # KHz
				pac5xxx_timer_base_config(TimerA, pwm_period_ticks, 0, TxCTL_MODE_UP, 0);	// Configure Timer
				iq_pid.max_value = pwm_period_ticks << 16;

				//iq_pid.Td = fix16_div(FIX16(0.1024), (app_pwm_period << 16));	//1024 / (10 * PWM_FREQ_KHZ)
				iq_pid.Td = fix16_div(IQ_PI_TD, (app_pwm_period << 16));	//1024 / (PWM_FREQ_KHZ * ADC_FREQ)
				iq_pid.Td = fix16_mul_new_16_16(iq_pid.Td, iq_pid.Ki);		//IQ PID TD must include both the TD as well as the KI
				}
			break;
		case parm_over_current_limit:
			app_over_current_limit = spi_data;
			pac5xxx_tile_register_write(ADDR_HPDAC, app_over_current_limit);
		break;
		case parm_current_command:
			iq_ref_command = spi_data;
		break;
		case parm_current_Kp:
			iq_pid.Kp = spi_data;
		break;
		case parm_current_Ki:
			iq_pid.Ki = spi_data;
			iq_pid.Td = fix16_div(IQ_PI_TD, (app_pwm_period << 16));	//1024 / (PWM_FREQ_KHZ * ADC_FREQ)
			iq_pid.Td = fix16_mul_new_16_16(iq_pid.Td, iq_pid.Ki);		//IQ PID TD must include both the TD as well as the KI
		break;
		case parm_current_min:
			iq_pid.min_value = (spi_data) << 16;
		break;
		case parm_current_max:
			iq_pid.max_value = (spi_data) << 16;
		break;
		case parm_speed_command:
			closed_loop_speed_hz = spi_data;
			speed_ref_command = HertzToTicks(closed_loop_speed_hz, (TIMER_D_FREQ_F16 >> timer_d_div)) ;
		break;
		case parm_speed_Kp:
			speed_pid.Kp = spi_data;
		break;
		case parm_speed_Ki:
			speed_pid.Ki = spi_data;
		break;
		case parm_speed_min:
			speed_pid.min_value = (spi_data) << 16;
		break;
		case parm_speed_max:
			speed_pid.max_value = (spi_data) << 16;
		break;
		case parm_dt_leading_ticks:
			dt_leading_ticks = spi_data >> 16;
			Set_Dead_Time();
		break;
		case parm_dt_trailing_ticks:
			dt_trailing_ticks = spi_data >> 16;
			Set_Dead_Time();
		break;
		case parm_oc_reset:
			oc_reset();
		break;
		case parm_timer_d_div:
			timer_d_div = spi_data >> 16;
		break;
		case parm_sample_delay:
			sample_delay = spi_data >> 16;
			pac5xxx_timer_cctrl_config(TimerA, 2, sample_delay, 0);
		break;
		case parm_blanking_cycles:
			blanking_cycles = spi_data >> 16;
		break;
		case parm_good_samples:
			good_samples = spi_data >> 16;;
		break;
		case parm_ol_accel_period:
			ol_accel_period = spi_data >> 16;
		break;
		case parm_ol_accel_increase:
			ol_accel_increase = spi_data >> 16;
		break;
		case parm_on_off:
			if (spi_data)
				{
				SMS_State = SMS_Align;
				}
			else
				{
				motor_pwm_disable();
				}
		break;
		case parm_stall_detect_speed_hz:
			//feature removed
		break;
		case parm_stall_detect_time_ms:
			//feature removed
		break;
		case parm_commutation_advanced_rise_delay:
			__disable_irq();
			commutation_advanced_rise = spi_data;
			commutation_advanced_rise = fix16_mul_new_16_16(commutation_advanced_rise, HALF_DEGREE_ADV_DLY);
			__enable_irq();
		break;
		case parm_commutation_advanced_fall_delay:
			__disable_irq();
			commutation_advanced_fall = spi_data;
			commutation_advanced_fall = fix16_mul_new_16_16(commutation_advanced_fall, HALF_DEGREE_ADV_DLY);
			__enable_irq();
		break;
		case parm_start_iq_ref:
			start_iq_ref = spi_data >> 16;
		break;
		case parm_align_time_ms:
			align_time_ms = spi_data >> 16;
		break;
		case parm_ol_start_hz:
			ol_start_hz = spi_data >> 16;
		break;
		case parm_ol_switchover_hz:
			ol_switchover_hz = spi_data >> 16;
        break;
		case parm_debug_array:
			debug_index = spi_data >> 16;
		break;
		case parm_pi_debug_index:
			pi_debug_index = spi_data;
		break;
		case parm_speed_ref_command_hz:
			speed_ref_command_hz = spi_data >> 16;
		break;
		case parm_cl_accel_period:
			cl_accel_period = spi_data >> 16;
		break;
		case parm_cl_accel_increase:
			cl_accel_increase = spi_data >> 16;
		break;
		default:
		break;
		}

}

void spi_read_from_slave_process()
{
	spi_data = (spi_buffer[0] & 0xFFFF) << 16;
	spi_data |= (spi_buffer[1] & 0xFFFF);
	spi_opcode = (spi_buffer[1] & 0x7F0000) >> 16;

	switch (spi_opcode)
		{
		case parm_status:
			PAC5XXX_SPI->SPID.w = app_status;
			break;
		case parm_debug_1:
			PAC5XXX_SPI->SPID.w = debug_1;
			break;
		case parm_debug_2:
			PAC5XXX_SPI->SPID.w = debug_2;
			break;
		case parm_debug_3:
			PAC5XXX_SPI->SPID.w = debug_3;
			break;
		case parm_debug_4:
			PAC5XXX_SPI->SPID.w = debug_4;
			break;
		case parm_pwm_period:
			PAC5XXX_SPI->SPID.w = app_pwm_period;
			break;
		case parm_over_current_limit:
			PAC5XXX_SPI->SPID.w = app_over_current_limit;
			break;
		case parm_dt_leading_ticks:
			PAC5XXX_SPI->SPID.w = dt_leading_ticks;
			break;
		case parm_dt_trailing_ticks:
			PAC5XXX_SPI->SPID.w = dt_trailing_ticks;
			break;
		case parm_vpot:
			PAC5XXX_SPI->SPID.w = pot_volts;
			break;
		case parm_vin:
			PAC5XXX_SPI->SPID.w = vin_volts;
			break;
		case parm_motor_speed:
			PAC5XXX_SPI->SPID.w = avg_speed;
			break;
		case parm_debug_array:
			PAC5XXX_SPI->SPID.w = debug_array[debug_index];
			break;
		case parm_pi_debug_error:
			PAC5XXX_SPI->SPID.w = pi_debug_value[pi_debug_index][0];
			break;
		case parm_pi_debug_p:
			PAC5XXX_SPI->SPID.w = pi_debug_value[pi_debug_index][1];
			break;
		case parm_pi_debug_i:
			PAC5XXX_SPI->SPID.w = pi_debug_value[pi_debug_index][2];
			break;
		case parm_pi_debug_pi:
			PAC5XXX_SPI->SPID.w = pi_debug_value[pi_debug_index][3];
			break;
		case parm_pi_debug_pisat:
			PAC5XXX_SPI->SPID.w = pi_debug_value[pi_debug_index][4];
			break;
		default:
			break;
	}
}






