/****************************************************************************
 * @file     isr_TimerD.c
 * @brief    Timer D Interrupt Service Routine
 * @date     22 September 2015
 *
 * @note
 * Copyright (C) 2015, Active-Semi International
 *
 * THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES,
 * AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S
 * APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL;
 * (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT
 * ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
 * DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
 * ONLY BY CERTAIN AUTHORIZED PERSONS.
 ******************************************************************************/
#define INCLUDE_EXTERNS
#include "bldc_common.h"

#ifdef RC_PWM_THROTTLE_APP
/**
 * @brief  The state machine is in charge of coordination motor operation. Interval is 1 ms.
 *
 * @return none
 *
 */
void state_machine(void)
{
	switch (SMS_State)
		{
		case SMS_Idle:
			//do nothing
			break;
		case SMS_Radio_Gone:
			if (rc_status == RCPresent)
				{
				SMS_State = SMS_Radio_Present;
				}
			break;
		case SMS_Radio_Present:
			if (!(app_status & status_motor_enabled) && (speed_ref_command_hz >= RC_SPEED_TH_HZ_ON) && !(app_status & status_motor_stalled) && !(app_status & status_under_voltage))
				{
				SMS_State = SMS_Align;
				}
			else if ((app_status & status_motor_enabled) && speed_ref_command_hz < RC_SPEED_TH_HZ_OFF)
				{
				motor_pwm_disable();
				SMS_State = SMS_Disable_Wait;
				SMS_Counter = 200;
				}
			else if (!(app_status & status_motor_enabled) && speed_ref_command_hz < RC_SPEED_TH_HZ_OFF)
				{
				app_status &= ~status_motor_stalled;
				}
			break;

		case SMS_Disable_Wait:
			if (--SMS_Counter <= 0)
				{
				SMS_State = SMS_Radio_Gone;
				}
			break;
		case SMS_Align:
			app_status &= ~status_motor_stalled;
#if PAC5250
		PAC5XXX_GPIOA->OUTEN.b = MOTOR_PWM_PIN_PORT_A;
		PAC5XXX_GPIOA->PSEL.s = 0x5015;	        // All drives are PWM

		PAC5XXX_GPIOD->OUTEN.b = MOTOR_PWM_PIN_PORT_D;
		PAC5XXX_GPIOD->PSEL.s = 0x4005;	        // All drives are PWM
#else
		PAC5XXX_GPIOA->OUTEN.b = MOTOR_PWM_PIN_PORT_A;
		PAC5XXX_GPIOA->PSEL.s = 0x0595;	        // All drives are PWM
#endif

#if BLDC_DIRECTION
			sine_index = 0;
#else
			sine_index = 359;
#endif
			sine_scale_increase = fix16_mul_new_16_16(pwm_period_ticks << 16, SCALE_PERCENT);
			sine_scale_increase = fix16_div(sine_scale_increase, align_time_ms << 16) >> 16;
			sine_scale = 0;

			fix16_t temp0, temp1, temp2;

			temp0 = fix16_mul_new_16_16(sine_wave_3phase[sine_index][0], sine_scale);
			temp1 = fix16_mul_new_16_16(sine_wave_3phase[sine_index][1], sine_scale);
			temp2 = fix16_mul_new_16_16(sine_wave_3phase[sine_index][2], sine_scale);

			PAC5XXX_TIMERA->CTR4 = temp0;
			PAC5XXX_TIMERA->CTR5 = temp1;
			PAC5XXX_TIMERA->CTR6 = temp2;

			blanking_cycles = START_BLANKING_CYCLES;
			good_samples = START_GOOD_SAMPLES;

			SMS_Counter = 0;
			SMS_State = SMS_Align_Wait;
			app_status |= status_motor_enabled;
			open_loop = 1;
			sine_mode = 1;
			break;
	case SMS_Align_Wait:
		SMS_Counter ++;
		if (SMS_Counter >= align_time_ms)
			{
			SMS_Counter = 0;
			SMS_State = SMS_Start_Motor;
			}
		else
			{
			sine_scale += sine_scale_increase;

			fix16_t temp0, temp1, temp2;
			temp0 = fix16_mul_new_16_16(sine_wave_3phase[sine_index][0], sine_scale);
			temp1 = fix16_mul_new_16_16(sine_wave_3phase[sine_index][1], sine_scale);
			temp2 = fix16_mul_new_16_16(sine_wave_3phase[sine_index][2], sine_scale);

			PAC5XXX_TIMERA->CTR4 = temp0;
			PAC5XXX_TIMERA->CTR5 = temp1;
			PAC5XXX_TIMERA->CTR6 = temp2;
			}
		break;

	case SMS_Align_Hold:
		SMS_Counter++;
		if (SMS_Counter > 10)
		{
			SMS_State = SMS_Start_Motor;
		}
		break;

	case SMS_Start_Motor:
		speed_ref_hz = ol_start_hz;
		speed_ref_ticks = HertzToTicksSine((speed_ref_hz << 16), (TIMER_D_FREQ_F16 >> timer_d_div));
		pac5xxx_timer_base_config(TimerD, (speed_ref_ticks >> 16), 0, TxCTL_MODE_UP, 0);
		pac5xxx_timer_base_int_enable(TimerD, 1);									// Enable Timer D Base Interrupt
		NVIC_EnableIRQ(TimerD_IRQn);
		SMS_State = SMS_Accel_Motor;
		SMS_Counter = 0;
		avg_speed_index = 0;
		break;

	case SMS_Accel_Motor:
		SMS_Counter++;
		if (SMS_Counter >= ol_accel_period)
			{
			SMS_Counter = 0;
			speed_ref_hz += ol_accel_increase;
			if (speed_ref_hz > ol_switchover_hz)
				{

				pac5xxx_timer_base_int_enable(TimerD, 0);
				sine_mode = 0;

				PAC5XXX_GPIOA->PSEL.s = psel_mask[sl_current_state];	        // Set peripheral select state
#if PAC5250
				PAC5XXX_GPIOD->PSEL.s = psel_mask_port_d[sl_current_state];
#endif
				PAC5XXX_GPIOA->OUT.b = c_pwm_io_state[sl_current_state];		// Set output state for GPIO pins
				sl_current_state++;

			#if IREG
				iq_ref = start_iq_ref << 16;
				iq_pid.PI_sat = iq_pid.min_value;
				iq_pid.I_prev = iq_pid.min_value;

				speed_pid.PI_sat = iq_ref;
				speed_pid.I_prev = iq_ref;
			#else
				speed_pid.PI_sat = iq_pid.min_value;
				speed_pid.I_prev = iq_pid.min_value;
			#endif
				motorspeed = HertzToTicks(speed_ref_hz << 16, (TIMER_D_FREQ_F16 >> timer_d_div)) >> 16;
			    PAC5XXX_TIMERD->CTR0 = motorspeed >> 1;
			    PAC5XXX_TIMERD->CTL.CLR = 1;						//Clear Timer D
				PAC5XXX_TIMERD->PRD = 0x0001;						//Change Timer D period to force a TCCR0 update
			    PAC5XXX_TIMERD->CTL.CLR = 0;						//Timer D starts to run
			    while (PAC5XXX_TIMERD->CTR0 != motorspeed >> 1);	//Wait until Timer D CCR0 register has been updated
			    PAC5XXX_TIMERD->PRD = 0xFFFF;						//Bring back Timer D period to maximum

			    tmp_blanking_cycles = blanking_cycles;
			    PAC5XXX_TIMERC->CCTRL0.CCINTEN = 0;
			    PAC5XXX_TIMERC->CCTRL0.CCINT = 1;
			    PAC5XXX_TIMERD->CCTRL0.CCINT = 1;
			    PAC5XXX_TIMERD->CTL.INT = 1;
			    PAC5XXX_TIMERD->CCTRL0.CCINTEN = 1;
				NVIC_EnableIRQ(TimerC_IRQn);
				NVIC_EnableIRQ(TimerD_IRQn);

				char i;
				avg_speed = 0;
				for (i=0;i<=5;i++)
					{
					avg_speed_array[i] = motorspeed;
					}
				avg_speed = motorspeed;
				open_loop = 0;

				app_status |= status_closed_loop;
				SMS_State = SMS_StartUp;
				}
			else
				{
				speed_ref_ticks = HertzToTicksSine(speed_ref_hz << 16, (TIMER_D_FREQ_F16 >> timer_d_div));
				pac5xxx_timer_base_config(TimerD, (speed_ref_ticks >> 16), 0, TxCTL_MODE_UP, 0);
				motorspeed = HertzToTicks(speed_ref_hz << 16, (TIMER_D_FREQ_F16 >> timer_d_div)) >> 16;
				}
			}
		break;

		case SMS_StartUp:
			SMS_Counter++;
			if (SMS_Counter > OL_CL_TRANSITION_MS)
				{
				SMS_State = SMS_Radio_Present;
				blanking_cycles = RUN_BLANKING_CYCLES;
				good_samples = RUN_GOOD_SAMPLES;
				}
		break;
		}
	//Always Update Radio Status
	if (rc_status == RCGone && (app_status & status_motor_enabled))
		{
		motor_pwm_disable();
		SMS_State = SMS_Radio_Gone;
		}
	else if (rc_status == RCGone)
		{
		SMS_State = SMS_Radio_Gone;
		}
}
#endif
