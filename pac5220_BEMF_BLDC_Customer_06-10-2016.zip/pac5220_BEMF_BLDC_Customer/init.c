/****************************************************************************
 * @file     init.c
 * @brief    BLDC Initialization
 * @date     13 February 2015
 *
 * @note
 * Copyright (C) 2015, Active-Semi International
 *
 * THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES,
 * AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S
 * APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL;
 * (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT
 * ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
 * DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
 * ONLY BY CERTAIN AUTHORIZED PERSONS.
 ******************************************************************************/
#define INCLUDE_EXTERNS
#include "bldc_common.h"

void app_init(void)
{
	last_sample_stored = 0;						// Last good commutation state sample store

	app_over_current_limit = 50;

	sample_delay = SAMPLE_DELAY_DEF;
	pac5xxx_timer_cctrl_config(TimerA, 2, sample_delay, 0);

	closed_loop_speed_hz = START_SPEED_HZ << 16;
	speed_ref_command = HertzToTicks(closed_loop_speed_hz, (TIMER_D_FREQ_F16 >> timer_d_div));
	speed_ref_ticks = speed_ref_command;
	speed_ref_command_hz = START_SPEED_HZ;
	speed_ref_hz = speed_ref_command_hz;

	blanking_cycles = START_BLANKING_CYCLES;
	good_samples = START_GOOD_SAMPLES;

	SMS_Counter = 0;
	SMS_State = SMS_Idle;

	start_iq_ref = START_IQ_REF_DEF;
	align_time_ms = ALIGN_TIME_MS_DEF;
	ol_start_hz = OL_START_HZ_DEF;
	ol_switchover_hz = OL_SWITCHOVER_HZ_DEF;

	ol_accel_period = DEFAULT_OL_ACCEL_PERIOD;
	ol_accel_increase = DEFAULT_OL_ACCEL_INC;

	cl_accel_period = DEFAULT_CL_ACCEL_PERIOD;
	cl_accel_increase = DEFAULT_CL_ACCEL_INC;
	tmp_cl_accel = 0;

	commutation_advanced_rise = ADV_DLY_DEF << 16;
	commutation_advanced_fall = ADV_DLY_DEF << 16;

	commutation_advanced_rise = fix16_mul_new_16_16(commutation_advanced_rise, HALF_DEGREE_ADV_DLY);
	commutation_advanced_fall = fix16_mul_new_16_16(commutation_advanced_fall, HALF_DEGREE_ADV_DLY);

	open_loop = 1;
	sine_mode = 1;

	vin_check_debounce = VIN_CHECK_DEB_MAX;

	millisecond = 0;

	beep_freq_hz = BEEP_FREQ_HZ_DEF;
	beep_pwm_dc = BEEP_PWM_DC_DEF;

#ifdef RC_PWM_THROTTLE_APP
	rc_status = RCGone;
#endif
}

void pi_init(void)
{

#if IREG
	iq_pid.Kp = IQ_PI_KP;
	iq_pid.Ki = IQ_PI_KI;
	iq_pid.min_value = IQ_PI_MIN << 16;
	iq_pid.PI_sat = iq_pid.min_value;
	iq_pid.I_prev = iq_pid.min_value;
	iq_pid.max_value = IQ_PI_MAX << 16;

	iq_pid.Td = fix16_div(IQ_PI_TD, (app_pwm_period << 16));	//1024 / (PWM_FREQ_KHZ * ADC_FREQ)
	iq_pid.Td = fix16_mul_new_16_16(iq_pid.Td, iq_pid.Ki);		//IQ PID TD must include both the TD as well as the KI

	speed_pid.Td = SPEED_PI_TD;
	speed_pid.Kp = SPEED_PI_KP;
	speed_pid.Ki = SPEED_PI_KI;
	speed_pid.min_value = SPEED_PI_MIN << 16;
	speed_pid.max_value = SPEED_PI_MAX << 16;

	speed_pid.Td = fix16_mul_new_16_16(speed_pid.Td, speed_pid.Ki);

#else
	speed_pid.Td = SPEED_PI_TD;
	speed_pid.Kp = IQ_PI_KP;
	speed_pid.Ki = IQ_PI_KI;
	speed_pid.min_value = IQ_PI_MIN << 16;
	speed_pid.max_value = IQ_PI_MAX << 16;

	speed_pid.Td = fix16_mul_new_16_16(speed_pid.Td, speed_pid.Ki);
#endif
}

#if COMM_SUPPORT
/**
 * @brief  This function configures the UART Serial Communications Block
 *
 * @return none
 *
 */
void UART_init(void) {
	// Configure UART IO
	pac5xxx_uart_io_config();
	pac5xxx_gpio_out_pull_up_e(0x0C);

	// Configure UART peripheral
	pac5xxx_uart_config_LCR(UART_BPC_8,						// Bits per character
							UART_STOP_BITS_1,				// Stop Bits
							0,								// Parity Enabled
							0,								// Parity Type
							0,								// Stick Parity
							UART_BRKCTL_NORMAL,				// Break Control
							1);								// Divisor Latch Access

	// Configure UART clock for baud rate
#define	HCLOCK_FREQ		50000000
#define BAUD			115200
#define	BAUD_HIGH		HCLOCK_FREQ / (BAUD * 16)
#define	BAUD_LOW		((HCLOCK_FREQ / (BAUD * 16.0)) - BAUD_HIGH) * 256

	pac5xxx_uart_config_divisor_latch(BAUD_HIGH); 				// BAUD = 50 MHz/(115200*16) = 13.563368 -> divisor = 13; fractional: 0.12674*256 = 32
	pac5xxx_uart_config_fractional_divisor(BAUD_LOW);

	// Configure UART peripheral for access to FIFO from this point on
	pac5xxx_uart_fifo_access();

	// Enable FIFOs, so that the interrupts will work properly
	pac5xxx_uart_fifo_enable(1);

	// Enable receive data available interrupt and NVIC for UART interrupts
	pac5xxx_uart_int_enable_RDAI(1);
	NVIC_SetPriority(UART_IRQn, 3);			// Set lowest priority
	NVIC_EnableIRQ(UART_IRQn);
}

#endif

#if SPI_SUPPORT
void SPI_init()
{
#define	SPI_MISO	0x04
#define	SPI_PSEL	0x055

	// Configure SPI IO
	// PE3: CS0 - PE2:MISO - PE1: MOSI - PE0: CLK
	PAC5XXX_GPIOE->OUTEN.b |= SPI_MISO;
	pac5xxx_gpio_peripheral_select_e(SPI_PSEL);

	// Configure SPI peripheral as Slave
	pac5xxx_spi_slave_config(	1,							//Interrupt Enable
								0);							//Loop Back

	// Configure Word Length, LSB/MSB first, Clock Polarity, Clock Phase and Transmit Data Phase
	pac5xxx_spi_slave_config2	(SPISCFG_WL_32B,			//Word Length Select
								0,							//Reset SPI
								0,							//MSB First
								SPISCFG_SCLK_ACTLOW,		//Clock Polarity
								SPISCFG_SETUP_SMP,			//Clock Phase
								SPISCFG_TDAT_PH_NORMAL);	//Transmit Data Phase

	// Configure Chip Select, CS Polarity, Setup/Hold/Wait times
	pac5xxx_spi_slave_config_chip_select(
								SPICS_SELECT_CS0,			//Chip Select 0
								SPICS_CS_ACTLOW);			//Chip Select Polarity Type

	// Configure CLK Divider
	pac5xxx_spi_clock_divider(12);

	// Configure Cycle Done Interrupt
	pac5xxx_spi_int_enable_CYC_DONE(1);
	NVIC_SetPriority(SPI_IRQn, 3);
	NVIC_EnableIRQ(SPI_IRQn);

	//Enable SPI Block
	pac5xxx_spi_enable(1);
}
#endif

/*
 *
 * Configure ADC sampling engine:
 * =============================
 *
 * 	  Mode: 		Independent AS0 Trigger
 *    Repeat: 		on
 *    Divider:		/3 (PLLCLK = 50MHz/3 = 16.66MHz)
 *    Seq time: 	15 clocks (13 convert, 1 copy, 1 state machine switch) * (1/16.66MHz) = 0.9us
 *
 *    Emux Divider:	/2 (HCLK = 50MHz/2 = 25MHz)
 *
 *    AS0 Series:	Trigger: PWMC0
 *
 *    Seq #			Signal				Time offset (conversion to AS1 trigger/period end)
 *    -----------------------------------------------------------------------------------------
 *     Seq 0: 		HBI	 				-4.0 us
 *
 */

#if SINGLE_SHUNT
void adc_init(void)
{
	pac5xxx_adc_enable(0);
	// EMUX configuration
	pac5xxx_adc_emux_config(ADCEMUXCTL_EMUXC_SEQ, ADCEMUXCTL_EMUXDIV_DIV2);	 		// Configure EMUX to do conversions from ADC sequencer, /2 EMUX divider (HCLK=50MHz/2 = 25MHz)
	pac5xxx_adc_config_emux_io();													// Configure device IO for EMUX

	//ADC configuration
#if	PLL_FREQ_100
	pac5xxx_adc_config(ADCCTL_ADSTART_AUTO_01_IND_TRIG, ADCCTL_ADCDIV_DIV6, 1);		// Configure ADC for ASC0 independent trigger sequence, /3 divider (PLLCLK=100MHz/3=16.66MHz), repeat mode
#else
	pac5xxx_adc_config(ADCCTL_ADSTART_AUTO_01_IND_TRIG, ADCCTL_ADCDIV_DIV3, 1);		// Configure ADC for ASC0 independent trigger sequence, /3 divider (PLLCLK=50MHz/3=16.66MHz), repeat mode
#endif
	pac5xxx_adc_config_io(ADC_CHANNEL_MASK);										// Configure device IO for ADC conversions (as Analog inputs)
	//AS0 configuration
	pac5xxx_adc_as0_config_pwm(ADCCTLX_AS1D_DEPTH6, ADCCTLX_TRIGEDGE_HITOLOW, ADCCTLX_TRIGPWM_PWMA2);								// Configure AS0 for 2 conversion sequences, triggered by PWMA3

#if ADC_VIN_PC3
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_VIN, ADCCTL_ADMUX_AD3, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBI_EDATA, ASSEQ_DELAY_0);			// Convert VIN  (AD3)
#else
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_VIN, ADCCTL_ADMUX_AD4, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBI_EDATA, ASSEQ_DELAY_0);				// Convert VIN  (AD3)
#endif
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_HBI0, ADCCTL_ADMUX_AD0, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBI_EDATA, ASSEQ_DELAY_0);			// Convert HBI  (AD0)
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_HBI1, ADCCTL_ADMUX_AD0, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBI_EDATA, ASSEQ_DELAY_0);			// Convert HBI  (AD0)
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_HBI2, ADCCTL_ADMUX_AD0, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBI_EDATA, ASSEQ_DELAY_0);			// Convert HBI  (AD0)
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_HBI3, ADCCTL_ADMUX_AD0, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBI_EDATA, ASSEQ_DELAY_0);			// Convert HBI  (AD0)
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_VPOT, ADCCTL_ADMUX_AD4, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBI_EDATA, ASSEQ_DELAY_0);			// Convert VIN  (AD3)

	// Enable ADC interrupts on AS0 for control loop
	pac5xxx_adc_int_enable_as0(1);													// Enable interrupts for AS0 complete
	NVIC_SetPriority(ADC_IRQn, 2);													// Configure interrupt priority
	NVIC_EnableIRQ(ADC_IRQn);														// Enable ADC interrupts in the NVIC

	// Enable ADC
	pac5xxx_adc_enable(1);
	pac5xxx_adc_start();
}

#else
void adc_init(void)
{
	pac5xxx_adc_enable(0);
	// EMUX configuration
	pac5xxx_adc_emux_config(ADCEMUXCTL_EMUXC_SEQ, ADCEMUXCTL_EMUXDIV_DIV2);	 		// Configure EMUX to do conversions from ADC sequencer, /2 EMUX divider (HCLK=50MHz/2 = 25MHz)
	pac5xxx_adc_config_emux_io();													// Configure device IO for EMUX

	//ADC configuration
#if	PLL_FREQ_100
	pac5xxx_adc_config(ADCCTL_ADSTART_AUTO_01_IND_TRIG, ADCCTL_ADCDIV_DIV6, 1);		// Configure ADC for ASC0 independent trigger sequence, /3 divider (PLLCLK=100MHz/3=16.66MHz), repeat mode
#else
	pac5xxx_adc_config(ADCCTL_ADSTART_AUTO_01_IND_TRIG, ADCCTL_ADCDIV_DIV3, 1);		// Configure ADC for ASC0 independent trigger sequence, /3 divider (PLLCLK=50MHz/3=16.66MHz), repeat mode
#endif
	pac5xxx_adc_config_io(ADC_CHANNEL_MASK);										// Configure device IO for ADC conversions (as Analog inputs)
	//AS0 configuration
	pac5xxx_adc_as0_config_pwm(ADCCTLX_AS1D_DEPTH8, ADCCTLX_TRIGEDGE_HITOLOW, ADCCTLX_TRIGPWM_PWMA2);								// Configure AS0 for 2 conversion sequences, triggered by PWMA3

#if ADC_VIN_PC3
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_VIN, ADCCTL_ADMUX_AD3, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBU_EDATA, ASSEQ_DELAY_0);			// Convert VIN  (AD3)
#else
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_VIN, ADCCTL_ADMUX_AD4, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBU_EDATA, ASSEQ_DELAY_0);				// Convert VIN  (AD3)
#endif
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_U1, ADCCTL_ADMUX_AD0, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBV_EDATA, ASSEQ_DELAY_0);			// Convert HBI  (AD0)
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_V1, ADCCTL_ADMUX_AD0, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBW_EDATA, ASSEQ_DELAY_0);			// Convert HBI  (AD0)
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_W1, ADCCTL_ADMUX_AD0, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBU_EDATA, ASSEQ_DELAY_0);			// Convert HBI  (AD0)
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_VPOT, ADCCTL_ADMUX_AD4, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBU_EDATA, ASSEQ_DELAY_0);			// Convert HBI  (AD0)
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_U2, ADCCTL_ADMUX_AD0, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBV_EDATA, ASSEQ_DELAY_0);			// Convert VIN  (AD3)
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_V2, ADCCTL_ADMUX_AD0, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBW_EDATA, ASSEQ_DELAY_0);			// Convert HBI  (AD0)
	pac5xxx_adc_as0_sequence_config(ADC_SEQ_W2, ADCCTL_ADMUX_AD0, ASSEQ_MSPI_AFTER_SH, ADC_SEQ_HBU_EDATA, ASSEQ_DELAY_0);			// Convert HBI  (AD0)

	// Enable ADC interrupts on AS0 for control loop
	pac5xxx_adc_int_enable_as0(1);													// Enable interrupts for AS0 complete
	NVIC_SetPriority(ADC_IRQn, 2);													// Configure interrupt priority
	NVIC_EnableIRQ(ADC_IRQn);														// Enable ADC interrupts in the NVIC

	// Enable ADC
	pac5xxx_adc_enable(1);
	pac5xxx_adc_start();
}
#endif

/**
 * @brief  This function configures PAC analog peripheral
 *
 * @return none
 *
 */
void cafe_init(void)
{
	// Configure SOC Bridge for talking to MC02
	pac5xxx_tile_socbridge_config(1, 0);						// enable, int_enable

	// Write all CAFE registers
	pac5xxx_tile_register_write(ADDR_DEVID, 0x55);				// Write DEVID to value other than 0x00, 0xFF
	if (pac5xxx_tile_register_read(ADDR_PWRSTAT))				// If any power manager error bits set on startup, clear them
		pac5xxx_tile_register_write(ADDR_PWRSTAT, 0xFF);

	pac5xxx_tile_register_write(ADDR_PWRCTL, 0x40);				// Set MCUALIVE
	pac5xxx_tile_register_write(ADDR_PSTATSET, 0x80);			// Set UNLOCK bit to allow firmware to modify SCFG & CFGPWR0
	pac5xxx_tile_register_write(ADDR_SCFG, 0x3E);				// Set VCLAMPSEL (62V) and FMODE (181kHz to 500kHz buck)
	pac5xxx_tile_register_write(ADDR_IMOD, 0xFF);				// Set current modulation to 100%
	pac5xxx_tile_register_write(ADDR_ENBBM, 0x01);				// Enable make before break in driver tile

	//Configure DC/DC Switching Regulator
#if NODC
	pac5xxx_tile_register_write(0x15, 0xE0);					// CFGPWR0: Disable dc/dc, set vp to 15V (No Switching Regulator Hardware)
#else
	pac5xxx_tile_register_write(0x15, 0x80);					// CFGPWR0: enable dc/dc, set vp to 12V (SEPIC or Buck Switching Regulator Hardware)
#endif

	// Set HPROT and LPROT protection threshold
	pac5xxx_tile_register_write(ADDR_HPDAC, app_over_current_limit);	/* HPDAC: HPROT DAC (8b) */

#if SINGLE_SHUNT
	// Configure AIO54 for ADC sampling (Iu) with OC protection
	pac5xxx_tile_register_write(ADDR_CFGAIO0, 0x78);			// AIO10: DiffAmp, 48X gain, LPOPT disabled //was 0x58
	pac5xxx_tile_register_write(ADDR_CFGAIO1, 0x81);			// AIO10: nHP10PR1M set, NOT ENOS10, HPOPT (1us)
	// Enable protection interrupt mask
	pac5xxx_tile_register_write(ADDR_PROTINTM, 0x10);			// PROTINTM: nHP10INTM
#else
	// Configure AIO54 for ADC sampling (Iu) with OC protection
	pac5xxx_tile_register_write(ADDR_CFGAIO0, 0x68);			// AIO10: DiffAmp, 16X gain, LPOPT disabled
	pac5xxx_tile_register_write(ADDR_CFGAIO1, 0x81);			// AIO10: nHP10PR1M set, NOT ENOS10, HPOPT (1us) //81
	// Configure AIO32 for ADC sampling (Iv) with OC protection
	pac5xxx_tile_register_write(ADDR_CFGAIO2, 0x68);			// AIO32: DiffAmp, 16X gain, LPOPT disabled
	pac5xxx_tile_register_write(ADDR_CFGAIO3, 0x81);			// AIO32: nHP32PR1M set, NOT ENOS54, HPOPT (1us)
	// Configure AIO54 for ADC sampling (Iw) with OC protection
	pac5xxx_tile_register_write(ADDR_CFGAIO4, 0x68);			// AIO54: DiffAmp, 16X gain, LPOPT disabled
	pac5xxx_tile_register_write(ADDR_CFGAIO5, 0x81);			// AIO54: nHP54PR1M set, NOT ENOS54, HPOPT (1us)
	// Enable protection interrupt mask */
	pac5xxx_tile_register_write(ADDR_PROTINTM, 0x70);			// PROTINTM: nHP54INTM, nHP32INTM, nHP10INTM
#endif

	pac5xxx_tile_register_write(ADDR_CFGDRV1, 0xA0);			// Disable both HS and LS drivers on PR1 event (nHSPR1M=1, nLSPR1M=1)
	pac5xxx_tile_register_write(ADDR_SIGSET, 0xE8);				// Enable Comparators (7,8,9) Hysteresis; Set HP comparator hysteresis (HPROTHYS=1b)
	pac5xxx_tile_register_write(ADDR_SYSSTAT, 0x01);			// Turn on nINTM

	//Configure Sensorless Comparators
	pac5xxx_tile_register_write(ADDR_CFGAIO7, 0xD0);			// MODE7[1:0] = 11b (special mode), OPT7[1:0] = 01b (AB1 as COMP-), POL7 = 0 (act high), MUX[2:0] = n/a
	pac5xxx_tile_register_write(ADDR_CFGAIO8, 0xD0);			// MODE8[1:0] = 11b (special mode), OPT8[1:0] = 01b (bypass FF, select MUX out for nIRQ2/POS), POL8 = 0 (act high), MUX[2:0] = n/a
	pac5xxx_tile_register_write(ADDR_CFGAIO9, SLCOMP7);			// MODE9[1:0] = 01b (CT Vfilt), OPT9[1:0] = 0bxx (AIO7), POL9 = 0 (act high), MUX[2:0] = n/a

	pac5xxx_tile_register_write(ADDR_ADCSCAN, 0x18);			// ADCBUFEN=1 to enable ADC buffer, SCANEN=1 for auto-scan

	// Enable signal manager and verify active
	pac5xxx_tile_register_write(ADDR_ENSIG, 1);

	// Enable driver and verify active
	pac5xxx_tile_register_write(ADDR_ENDRV, 1);
}
