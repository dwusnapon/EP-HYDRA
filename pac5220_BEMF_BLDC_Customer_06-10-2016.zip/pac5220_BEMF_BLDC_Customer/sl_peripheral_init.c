/****************************************************************************
 * @file     hs_peripheral_init.h
 * @brief    Peripheral Initialization for the Hall Sensor Based BLDC Application
 * @date     22 September 2015
 *
 * @note
 * Copyright (C) 2015, Active-Semi International
 *
 * THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES,
 * AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S
 * APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL;
 * (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT
 * ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
 * DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
 * ONLY BY CERTAIN AUTHORIZED PERSONS.
 ******************************************************************************/
#define INCLUDE_EXTERNS
#include "bldc_common.h"

#ifdef SENSORLESS_APP

/**
 * @brief  This function configures the PAC peripherals for this application
 *
 * @return none
 *
 */
void peripheral_init(void)
{

#if PLL_FREQ_100
	// PLL Enabled @ 100MHz, HCLK runs at 50 MHz, ACLK runs at 100 MHz
	pac5xxx_sys_ccs_config(CCSCTL_CLKIN_CLKREF, CCSCTL_ACLKDIV_DIV1, CCSCTL_HCLKDIV_DIV2);
	pac5xxx_sys_pll_config(100);
	pac5xxx_sys_ccs_pll_select();
	pac5xxx_memctl_wait_state(FLASH_WSTATE_75MHZ_LT_HCLK_LTE_100MHZ);
#else
	// PLL Enabled @ 50MHz, HCLK runs at 50 MHz, ACLK runs at 50 MHz
	pac5xxx_sys_ccs_config(CCSCTL_CLKIN_CLKREF, CCSCTL_ACLKDIV_DIV1, CCSCTL_HCLKDIV_DIV1);
	pac5xxx_sys_pll_config(50);
	pac5xxx_sys_ccs_pll_select();
	pac5xxx_memctl_wait_state(FLASH_WSTATE_25MHZ_LT_HCLK_LTE_50MHZ);
#endif

	// Configure Timer A parameters. Timer A runs at PLL Frequency (selected above).
	pac5xxx_timer_clock_config(TimerA, TxCTL_CS_ACLK, TxCTL_PS_DIV1);
	app_pwm_period = PWM_SWITCH_FREQ;												// Number of KHz
	pwm_period_ticks = TIMER_A_FREQ_CNV / (app_pwm_period);							// 50,000 / # KHz
	pac5xxx_timer_base_config(TimerA, pwm_period_ticks, 0, TxCTL_MODE_UP, 0);		// Configure Timer

	// Configure Hardware Dead Time Generator
	dt_leading_ticks = DT_LED_TICKS;
	dt_trailing_ticks = DT_TED_TICKS;
	Set_Dead_Time();

	pac5xxx_timer_cctrl_config(TimerA, 4, pwm_period_ticks >> 1, 0);				// Configure CCR for VL
	pac5xxx_timer_cctrl_config(TimerA, 5, pwm_period_ticks >> 1, 0);				// Configure CCR for WH
	pac5xxx_timer_cctrl_config(TimerA, 6, pwm_period_ticks >> 1, 0);				// Configure CCR for WL

#if TUNING
	pac5xxx_timer_cctrl_config(TimerA, 3, 0, 0);									// PWMA3 DEBUG on PD2 - IREG PI
	pac5xxx_timer_cctrl_config(TimerA, 7, 0, 0);									// PWMA7 DEBUG on PD6 - SPEED PI
	pac5xxx_timer_io_select_pwma3_pd2();
	pac5xxx_timer_io_select_pwma7_pd6();
	pac5xxx_gpio_out_enable_d(0x44);
#endif

	// Configure nIRQ1 interrupt input signals and enable interrupts
	pac5xxx_gpio_int_mask_b(NIRQ1_PIN_MASK);										// Set interrupt mask at startup (interrupt startup workaround)
	pac5xxx_gpio_int_polarity_b(0);													// Set interrupt polarity (high-to-low)
	pac5xxx_gpio_int_enable_b(NIRQ1_PIN_MASK);										// Enable interrupts in IO controller
	NVIC_SetPriority(GpioB_IRQn, 2);
	NVIC_EnableIRQ(GpioB_IRQn);														// Enable interrupts in NVIC
	pac5xxx_gpio_int_flag_clear_b(NIRQ1_PIN_MASK);									// Clear any active interrupt flags
	pac5xxx_gpio_int_mask_b(0);														// Clear interrupt mask and interrupts are enabled

#if SPI_SUPPORT
	pac5xxx_gpio_out_enable_e(0x30);												// Set PE5, PE4, PE3, and PE0 to output
#else
	pac5xxx_gpio_out_enable_e(0x39);												// Set PE5, PE4, PE3, and PE0 to output
#endif

	// Configure CCR0 with interrupt enable(for reading new comparator value form float phase comparator)
	pac5xxx_timer_clock_config(TimerC, TxCTL_CS_ACLK, TxCTL_PS_DIV1);
	pac5xxx_timer_base_config(TimerC, TIMERC_PERIOD, 0, TxCTL_MODE_UP, 0);			// Configure Timer
	pac5xxx_timer_cctrl_config(TimerC, 0, (TIMERC_PERIOD >> 1), 1);
	NVIC_SetPriority(TimerC_IRQn, 1);

	// Configure timer for 30-degree calculation
	timer_d_div = 4;
	pac5xxx_timer_clock_config(TimerD, TxCTL_CS_HCLK, timer_d_div);
	pac5xxx_timer_base_config(TimerD, 0xFFFF, 0, TxCTL_MODE_UP, 0);
	NVIC_SetPriority(TimerD_IRQn, 0);												// Set Priority; Enablement will occur after Open Loop ends; Disablement will occur when motor is disabled

	//Configure SysTick Timer
    SysTick->LOAD = 50000;
    SysTick->VAL = 0;
    SysTick->CTRL |= (SysTick_CTRL_ENABLE_Msk +  SysTick_CTRL_CLKSOURCE_Msk + SysTick_CTRL_TICKINT_Msk);
	NVIC_SetPriority(SysTick_IRQn, 3);
}
#endif
