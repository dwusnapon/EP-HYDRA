//============================================================= 
//===== Auto Generated Project Build File - Do NOT Modify ===== 
//============================================================= 
 
#ifdef __GNUC__    // GNU C Compiler 
 
// COIDE FLASH_CRC_TEST Build-20160127.135438 
 
#ifndef FLASH_CRC_TEST_BUILD_INFO_H 
#define FLASH_CRC_TEST_BUILD_INFO_H 
 
#define FLASH_CRC_TEST_BUILD_STR   		"20160127.135438" 
#define FLASH_CRC_TEST_BUILD_DATE_STR		"20160127" 
#define FLASH_CRC_TEST_BUILD_DATE_NUM		20160127 
#define FLASH_CRC_TEST_BUILD_TIME_STR		"135438" 
#define FLASH_CRC_TEST_BUILD_TIME_NUM		135438 
 
#endif // FLASH_CRC_TEST_BUILD_INFO_H 
 
#endif // __GNUC__    GNU C Compiler 
