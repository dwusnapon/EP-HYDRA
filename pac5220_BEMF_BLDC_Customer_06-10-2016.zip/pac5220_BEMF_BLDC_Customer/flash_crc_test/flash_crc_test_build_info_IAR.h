//============================================================= 
//===== Auto Generated Project Build File - Do NOT Modify ===== 
//============================================================= 
 
#ifdef __ICCARM__  // IAR C Compiler 
 
// IAR FLASH_CRC_TEST Build-20160127.135442 
 
#ifndef FLASH_CRC_TEST_BUILD_INFO_H 
#define FLASH_CRC_TEST_BUILD_INFO_H 
 
#define FLASH_CRC_TEST_BUILD_STR   		"20160127.135442" 
#define FLASH_CRC_TEST_BUILD_DATE_STR		"20160127" 
#define FLASH_CRC_TEST_BUILD_DATE_NUM		20160127 
#define FLASH_CRC_TEST_BUILD_TIME_STR		"135442" 
#define FLASH_CRC_TEST_BUILD_TIME_NUM		135442 
 
#endif // FLASH_CRC_TEST_BUILD_INFO_H 
 
#endif // __ICCARM__  IAR C Compiler 
