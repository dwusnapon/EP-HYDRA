//============================================================= 
//===== Auto Generated Project Build File - Do NOT Modify ===== 
//============================================================= 
 
#ifdef __CC_ARM    // Keil RealView C Compiler 
 
// KEIL FLASH_CRC_TEST Build-20160127.135447 
 
#ifndef FLASH_CRC_TEST_BUILD_INFO_H 
#define FLASH_CRC_TEST_BUILD_INFO_H 
 
#define FLASH_CRC_TEST_BUILD_STR   		"20160127.135447" 
#define FLASH_CRC_TEST_BUILD_DATE_STR		"20160127" 
#define FLASH_CRC_TEST_BUILD_DATE_NUM		20160127 
#define FLASH_CRC_TEST_BUILD_TIME_STR		"135447" 
#define FLASH_CRC_TEST_BUILD_TIME_NUM		135447 
 
#endif // FLASH_CRC_TEST_BUILD_INFO_H 
 
#endif // __CC_ARM    Keil RealView C Compiler 
