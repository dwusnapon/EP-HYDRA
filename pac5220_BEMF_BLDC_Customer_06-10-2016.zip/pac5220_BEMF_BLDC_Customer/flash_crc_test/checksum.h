#ifndef CHECKSUM_H
#define CHECKSUM_H
unsigned short crc16_table_256(unsigned short sum, unsigned char *p, unsigned int len, unsigned short *p_crc16_table);
unsigned short crc16(unsigned short sum, unsigned char *p, unsigned int len);

extern unsigned short *crc16_table;

#endif  //CHECKSUM_H
