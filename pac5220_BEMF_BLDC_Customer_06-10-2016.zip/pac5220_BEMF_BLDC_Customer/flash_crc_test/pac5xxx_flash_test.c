//==============================================================================
/// @file    pac5xxx_flash_test.c
///   
/// @brief  This file contains functions to test Flash
///
/// @note
/// Copyright (C) 2016, Active-Semi International
///
/// THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES, 
/// AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S 
/// APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL; 
/// (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT 
/// ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
/// DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
/// ONLY BY CERTAIN AUTHORIZED PERSONS.
///
//==============================================================================

#include <stdint.h>
#include "pac52XX.h"
#include "pac5xxx_driver_system.h"
#include "pac5xxx_driver_memory.h"
#include "pac5xxx_flash_test.h"
#include "checksum.h"

void set_pll_and_test_flash_crc(void)
{
    uint32_t ret;

    // Set PLL and Device Clocks - PLL 50MHZ, FCLK: 50MHz, PLLCLK: 50MHz, ACLK: 50MHz (/1), HCLK: 50MHz (/1)
    pac5xxx_sys_pll_config(50);
    pac5xxx_sys_ccs_config(CCSCTL_CLKIN_CLKREF, CCSCTL_ACLKDIV_DIV1, CCSCTL_HCLKDIV_DIV1);
    pac5xxx_memctl_wait_state(FLASH_WSTATE_25MHZ_LT_HCLK_LTE_50MHZ);

#ifdef FLASH_CRC_TEST

    // Create 16-bit crc16 table in RAM at RAM Base Address, The memory will be reclaimed by the application
    // Note: The stack pointer should be at the top of RAM so there is no conflict
    make_crc16_table(RAM_BASE_ADDRESS_PTR);

    // Call fast flash test using generated RAM table
    ret = pac5xxx_fast_flash_crc_test(RAM_BASE_ADDRESS_PTR,                                         // Pointer to CRC Table
                                      (uint8_t *) VECTOR_TABLE_ADDR,                                // Start Address
                                      (uint32_t) &__crc16_checksum - (uint32_t)VECTOR_TABLE_ADDR,   // Size in bytes
                                      __crc16_checksum);                                            // Expected CRC Value


    // Store the results of the Flash CRC Test so the application can handle the CRC Failure
    set_reset_flash_crc_test_results(ret);  // CRC Passed-ret=0; CRC Failed-ret=1 (i.e. non zero)

#endif // FLASH_CRC_TEST

}

//==============================================================================
///
/// @brief  This function stores the result of the Reset Handler Flash CRC Test
///
/// @param  value - results of the Flash CRC Test:
///         CRC Passed-value=0
///         CRC Failed-value=1
///
/// @return none
///
//==============================================================================
void set_reset_flash_crc_test_results(int32_t value)
{
    // Set The UART Scratch Pad Register to the Flash CRC Test results
    PAC5XXX_UART->SP.VAL = value;  // CRC Passed-value=0; CRC Failed-value=1 (i.e. non zero)
}

//==============================================================================
///
/// @brief  This function returns the result of the Reset Handler Flash CRC Test
///
/// @return int32_t-results of the Flash CRC Test:
///         CRC Passed-value=0
///         CRC Failed-value=1
///
//==============================================================================
int32_t get_reset_flash_crc_test_results(void)
{
    // Return the Flash CRC Test results stored in the UART Scratch Pad Register
    return PAC5XXX_UART->SP.VAL;
}

//==============================================================================
///
/// @brief  This function performs a test of the flash using a 16-bit CRC
///
///         The test computes a 16-bit CRC checksum over the contents of the
///         specified memory.  If the results don't match the
///         checksum parameter passed in, then fail_safe is called.
///
/// @param  p_start_addr - starting address for the CRC calculation
/// @param  size_bytes   - size in bytes of the flash to be tested
/// @param  checksum     - CRC checksum to compare the test results agianst
///
/// @return int32_t 0= pass; 1=fail
///
//==============================================================================
int32_t pac5xxx_flash_crc_test(uint8_t *p_start_addr, uint32_t size_bytes, uint16_t checksum)
{
    uint16_t sum=0;
    const uint32_t zero=0;
    
    //===== Calculate the CRC using the previous sum and the remainder of the bytes =====
    sum = crc16(sum, p_start_addr, size_bytes);    

    //===== Push 16 more bits through to get the final sum =====
    sum = crc16(sum, (uint8_t *)&zero, 2);

    //===== Verify the final CRC against the stored CRC =====
    if (sum != checksum)
        return 1;
    else
		return 0;

}


//==============================================================================
///
/// @brief  This function performs a fast flash test using a CRC Table 
///
///         The test computes a 16-bit CRC checksum over the contents of the
///         flash used by the application.  The CRC calculation makes use of
///         a 256 entry CRC table to speed up the calculation.  If the results
///         don't match the checksum parameter passed in, then fail_safe is
///         called.
///
/// @param  p_table      - pointer to the CRC table
/// @param  p_start_addr - starting address for the CRC calculation
/// @param  size_bytes   - size in bytes of the flash to be tested
/// @param  checksum     - CRC checksum to compare the test results agianst
///
/// @return int32_t 0= pass; 1=fail
///
//==============================================================================
int32_t pac5xxx_fast_flash_crc_test(uint16_t *p_table, uint8_t *p_start_addr, uint32_t size_bytes, uint16_t checksum)
{
    uint16_t sum = 0;
    
    sum = crc16_table_256(sum, p_start_addr, size_bytes, p_table);

    if (sum != checksum)
        return 1;
	else
		return 0;

}

//==============================================================================
///
/// @brief  This function makes a 256 entry 16-bit CRC table on the fly in RAM
///
/// @param  p_crctable   - pointer to the CRC table
///
/// @return none
///
//==============================================================================
void make_crc16_table(uint16_t *p_crctable)
{
    int32_t value;
    int32_t i;
    int32_t j;

    for(i=0; i < 256; i++)
    {
        value = i << 8;

        for(j=0; j < 8; j++)
        {
           if(value & (1 << 15))
               value = (value << 1)^0x1021;
           else
               value = value << 1;
        }

        p_crctable[i]= value;
    }
}


