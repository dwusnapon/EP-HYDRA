/**************************************************************************//**
 * @file     flash_test_version.h
 * @brief    Version number
 *
 * @note
 * Copyright (C) 2016 Active Semiconductor. All rights reserved.
 *
 * @par
 * THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 * ARM SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 ******************************************************************************/

#ifndef FLASH_CRC_TEST_VERSION_H
#define FLASH_CRC_TEST_VERSION_H

#define FLASH_CRC_TEST_VERSION_MAJOR           1
#define FLASH_CRC_TEST_VERSION_MINOR           0
#define FLASH_CRC_TEST_VERSION_BUGFIX          0
#define FLASH_CRC_TEST_VERSION_RELEASE_STATE   0  //0=Released, 1=RC, 2=Beta, 3=Alpha
#define FLASH_CRC_TEST_VERSION_RELEASE_NUM     0
#define FLASH_CRC_TEST_VERSION_STR				"1.0.0"

// Include Library Build Information - Includes Build Date and Time
#if defined  __GNUC__				// GNU C Compiler
#include "flash_crc_test_build_info_COIDE.h"
#elif defined __ICCARM__ 			// IAR C Compiler
#include "flash_crc_test_build_info_IAR.h"
#elif defined __CC_ARM				// Keil RealView C Compiler
#include "flash_crc_test_build_info_KEIL.h"
#endif

#endif
