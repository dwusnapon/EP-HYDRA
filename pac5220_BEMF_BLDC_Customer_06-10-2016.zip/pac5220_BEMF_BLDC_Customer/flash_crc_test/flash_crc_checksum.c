//==============================================================================
/// @file    flash_checksum.c
///
/// @brief  This file contains a variable place holder for the CRC16 Checksum
///
/// @note
/// Copyright (C) 2016, Active-Semi International
///
/// THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES,
/// AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S
/// APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL;
/// (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT
/// ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
/// DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
/// ONLY BY CERTAIN AUTHORIZED PERSONS.
///
//==============================================================================


#include <stdint.h>

#ifdef __ICCARM__           // IAR C Compiler
// Nothing needed for IAR

#elif defined __GNUC__      // GNU C Compiler
// Nothing needed for GCC/COIDE

#elif defined __CC_ARM      // Keil RealView C Compiler
const uint16_t __crc16_checksum = 0xCAFE;

#endif
