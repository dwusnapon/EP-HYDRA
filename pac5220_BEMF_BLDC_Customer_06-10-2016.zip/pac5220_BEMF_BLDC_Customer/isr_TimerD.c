/****************************************************************************
 * @file     isr_TimerD.c
 * @brief    Timer D Interrupt Service Routine
 * @date     22 September 2015
 *
 * @note
 * Copyright (C) 2015, Active-Semi International
 *
 * THIS SOFTWARE IS SUBJECT TO A SOURCE CODE LICENSE AGREEMENT WHICH PROVIDES,
 * AMONG OTHER THINGS:  (i) THAT IT CAN BE USED ONLY TO ADAPT THE LICENSEE'S
 * APPLICATION TO PAC PROCESSORS SUPPLIED BY ACTIVE-SEMI INTERNATIONAL;
 * (ii) THAT  IT IS PROVIDED "AS IS" WITHOUT WARRANTY;  (iii) THAT
 * ACTIVE-SEMICONDUCTOR IS NOT LIABLE FOR ANY INDIRECT DAMAGES OR FOR DIRECT
 * DAMAGES EXCEEDING US$1,500;  AND (iv) THAT IT CAN BE DISCLOSED TO AND USED
 * ONLY BY CERTAIN AUTHORIZED PERSONS.
 ******************************************************************************/
#define INCLUDE_EXTERNS
#include "bldc_common.h"

#if defined SENSORLESS_APP || defined RC_PWM_THROTTLE_APP
/**
 * @brief	This is the interrupt handler for Timer D, which gets serviced 30 degrees after zero crossing.
 *			When this interrupt is serviced, it will set the current state to the next state.  The current
 *			state needs to change to the next state 30 degrees after the zero crossing has been detected.
 *
 * @return none
 *
 */
APP_RAMFUNC void TimerD_IRQHandler(void)
{
	if (PAC5XXX_TIMERD->CCTRL0.CCINT && PAC5XXX_TIMERD->CCTRL0.CCINTEN)
		{
		PAC5XXX_TIMERD->CCTRL0.CCINTEN = 0;
		PAC5XXX_GPIOA->OUT.b = c_pwm_io_state[sl_current_state];
		PAC5XXX_GPIOA->PSEL.s =  psel_mask[sl_current_state];
		#if PAC5250
		PAC5XXX_GPIOD->PSEL.s = psel_mask_port_d[sl_current_state];
		#endif

		// Switch mux to the sensorlesss comparator that needs to be monitored during the next state
		pac5xxx_tile_register_write_in(ADDR_CFGAIO9, slcomp_mux[sl_current_state]);

		sl_current_state++;
		if (sl_current_state > 5)
			sl_current_state = 0;

		open_loop = 0;
		getslcomp_state = TimerC_getslcomp_blanking_cycles;
		PAC5XXX_TIMERC->CCTRL0.CCINT = 1;
		PAC5XXX_TIMERC->CCTRL0.CCINTEN = 1;
		PAC5XXX_TIMERD->CCTRL0.CCINT = 1;
		}

	if (PAC5XXX_TIMERD->CTL.INT && PAC5XXX_TIMERD->CTL.INTEN)
		{
		if (sine_mode)
			{

#if BLDC_DIRECTION
			sine_index += 1;
			if (sine_index >= 360)
				sine_index = 0;

#else
			sine_index -= 1;
			if (sine_index >= 0xFFFE)
				sine_index = 359;
#endif

			fix16_t temp0, temp1, temp2;

			temp0 = fix16_mul_new_16_16(sine_wave_3phase[sine_index][0], sine_scale);
			temp1 = fix16_mul_new_16_16(sine_wave_3phase[sine_index][1], sine_scale);
			temp2 = fix16_mul_new_16_16(sine_wave_3phase[sine_index][2], sine_scale);

			PAC5XXX_TIMERA->CTR4 = temp0;
			PAC5XXX_TIMERA->CTR5 = temp1;
			PAC5XXX_TIMERA->CTR6 = temp2;

			sl_current_state = fix16_mul_new_16_16(sine_index, ONEDIV60);
			}
		else
			{
			PAC5XXX_GPIOA->OUT.b = c_pwm_io_state[sl_current_state];
			PAC5XXX_GPIOA->PSEL.s =  psel_mask[sl_current_state];
			#if PAC5250
			PAC5XXX_GPIOD->PSEL.s = psel_mask_port_d[sl_current_state];
			#endif

			// Switch mux to the sensorlesss comparator that needs to be monitored during the next state
			pac5xxx_tile_register_write_in(ADDR_CFGAIO9, slcomp_mux[sl_current_state]);

			sl_current_state++;
			if (sl_current_state > 5)
				sl_current_state = 0;
			getslcomp_state = TimerC_getslcomp_blanking_cycles;

			}
		PAC5XXX_TIMERD->CTL.INT = 1;
		}
}

#endif

#ifdef HALL_SENSOR_APP
/**
 * @brief Process Timer D Interrupts
 * Base D Not Used
 * PAC5220: PWMD0 FG (optional) /
 * PAC5223: PWMD0 PHASE W Hall Effect Sensor Input Capture (both rise and fall edges)
 * PAC522x: PWMD1 Not Used
 */
APP_RAMFUNC void TimerD_IRQHandler(void)
{
	if (PAC5XXX_TIMERD->CCTRL0.CCINT && PAC5XXX_TIMERD->CCTRL0.CCINTEN)
		{
#if PAC5223
		commutate();
#else
#endif
		PAC5XXX_TIMERD->CCTRL0.CCINT = 1;
		}
}
#endif
